export class AgendaAttendees {
    public AgendaAttendeesID : string = '00000000-0000-0000-0000-000000000000';
    public AgendaID :string = '00000000-0000-0000-0000-000000000000';
    public Email:string;
    constructor() {
    }
}