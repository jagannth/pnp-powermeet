export class StandardTemplate {
    id:1
    data: [];
    constructor(){
        this.data = []
    }
  }
  