export class MeetingAttendees {
    public MeetingAttendeesID : string;
    public MeetingID :string;
    public Email:string;
    public File:any;
    public Status:boolean;
    constructor() {
        this.MeetingAttendeesID = '00000000-0000-0000-0000-000000000000';
        this.MeetingID = '00000000-0000-0000-0000-000000000000';
    }
}