export class User {
    id: string;
    displayName: string;
    email: string;
    userPrincipalName: string;
    file: any;
    status: boolean;
    fullname: string;
    card:string;
  }
  