export const OAuthSettings = {
  
    appId: 'b8059a6e-6ef5-4769-9e08-5c3fac3fe552',
    // appId: '6d2502b5-1913-4cfc-a315-1820ca53ec2e',
    // appId: '77ae55ca-2847-4da7-af96-7c649059f634',
    scopes: [
      "user.read",
      "calendars.read",
      "ChannelMessage.Send","Group.ReadWrite.All"
    ],
    redirect_uri:'http://localhost:2400/Dashboard'
    // redirect_uri:'https://powermeet-dev.azurewebsites.net/Home'
  };