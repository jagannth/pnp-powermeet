export class ContextInfo {
    public email: string;
    public token: string;
    public tokenExpires: Date;
    public isAuthenticated: boolean;
    constructor() {
    }
}