export class Constants {
    public get meeting(): string { return "2edcd9d6-eddf-4e5b-90ed-bc4508f474bb" }
    public get agendaItem(): string { return "e5479599-a75d-4df8-8b06-7dd1ed82e563" }
} 