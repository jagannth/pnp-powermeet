export class AgendaDto {
    public title: string = "";
    public description: string = "";
    public duration: any = "";
    public taudience: Array<any> = [];
    public assignee: {};
    constructor() {
    }
}